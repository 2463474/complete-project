package com.example.ghim.service;

import com.example.ghim.dto.EmployeeReportDTO;
import com.example.ghim.dto.PolicyReportDTO;
import com.example.ghim.dto.ClaimReportDTO;
import com.example.ghim.entity.Employee;
import com.example.ghim.entity.Enrollment;
import com.example.ghim.entity.Policy;
import com.example.ghim.entity.Claim;
import com.example.ghim.repository.EmployeeRepository;
import com.example.ghim.repository.EnrollmentRepository;
import com.example.ghim.repository.PolicyRepository;
import com.example.ghim.repository.ClaimRepository;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.math.BigDecimal;

@Service
public class ReportService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private EnrollmentRepository enrollmentRepository;

    @Autowired
    private PolicyRepository policyRepository;

    @Autowired
    private ClaimRepository claimRepository;

    // Generates data for Employee Report
    public List<EmployeeReportDTO> generateEmployeeReport() {
        // In a real scenario, this would likely be a complex query.
        // For now, we simulate fetching enrolled employees.
        List<Enrollment> enrollments = enrollmentRepository.findAll();

        return enrollments.stream().map(enrollment -> {
            Employee emp = enrollment.getEmployee();
            return new EmployeeReportDTO(
                    emp.getEmployeeId(),
                    emp.getName(),
                    emp.getEmail(),
                    enrollment.getPolicy().getPolicyName(),
                    enrollment.getStatus().name());
        }).collect(Collectors.toList());
    }

    public List<PolicyReportDTO> generatePolicyReport() {
        List<Policy> policies = policyRepository.findAll();
        List<Enrollment> enrollments = enrollmentRepository.findAll();

        return policies.stream().map(policy -> {
            long count = enrollments.stream()
                    .filter(e -> e.getPolicy().getPolicyId().equals(policy.getPolicyId()) &&
                            "ACTIVE".equals(e.getStatus().name()))
                    .count();
            BigDecimal totalPremium = policy.getPremiumAmount().multiply(BigDecimal.valueOf(count));
            return new PolicyReportDTO(policy.getPolicyName(), policy.getPolicyType().name(), count, totalPremium);
        }).collect(Collectors.toList());
    }

    public List<ClaimReportDTO> generateClaimReport() {
        return claimRepository.findAll().stream().map(claim -> new ClaimReportDTO(
                claim.getClaimId(),
                claim.getEnrollment().getEmployee().getName(),
                claim.getEnrollment().getPolicy().getPolicyName(),
                claim.getClaimAmount(),
                claim.getClaimStatus().name(),
                claim.getClaimDate())).collect(Collectors.toList());
    }

    // Export Logic
    public ByteArrayInputStream exportReport(String reportType, String format) throws IOException {
        if ("EMPLOYEE".equalsIgnoreCase(reportType)) {
            List<EmployeeReportDTO> data = generateEmployeeReport();
            if ("PDF".equalsIgnoreCase(format)) {
                return generateEmployeePdf(data);
            } else if ("EXCEL".equalsIgnoreCase(format)) {
                return generateEmployeeExcel(data);
            }
        } else if ("POLICY".equalsIgnoreCase(reportType)) {
            List<PolicyReportDTO> data = generatePolicyReport();
            if ("PDF".equalsIgnoreCase(format)) {
                return generatePolicyPdf(data);
            } else if ("EXCEL".equalsIgnoreCase(format)) {
                return generatePolicyExcel(data);
            }
        } else if ("CLAIM".equalsIgnoreCase(reportType)) {
            List<ClaimReportDTO> data = generateClaimReport();
            if ("PDF".equalsIgnoreCase(format)) {
                return generateClaimPdf(data);
            } else if ("EXCEL".equalsIgnoreCase(format)) {
                return generateClaimExcel(data);
            }
        }
        // Add other report types here
        throw new IllegalArgumentException("Unsupported report type or format");
    }

    private ByteArrayInputStream generateEmployeePdf(List<EmployeeReportDTO> data) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PdfWriter writer = new PdfWriter(out);
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf);

        document.add(new Paragraph("Employee Enrollment Report"));

        Table table = new Table(5);
        table.addCell("ID");
        table.addCell("Name");
        table.addCell("Email");
        table.addCell("Policy");
        table.addCell("Status");

        for (EmployeeReportDTO dto : data) {
            table.addCell(String.valueOf(dto.getEmployeeId()));
            table.addCell(dto.getName());
            table.addCell(dto.getEmail());
            table.addCell(dto.getPolicyName());
            table.addCell(dto.getStatus());
        }

        document.add(table);
        document.close();

        return new ByteArrayInputStream(out.toByteArray());
    }

    private ByteArrayInputStream generateEmployeeExcel(List<EmployeeReportDTO> data) throws IOException {
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("Employees");

            Row headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("ID");
            headerRow.createCell(1).setCellValue("Name");
            headerRow.createCell(2).setCellValue("Email");
            headerRow.createCell(3).setCellValue("Policy");
            headerRow.createCell(4).setCellValue("Status");

            int rowIdx = 1;
            for (EmployeeReportDTO dto : data) {
                Row row = sheet.createRow(rowIdx++);
                row.createCell(0).setCellValue(dto.getEmployeeId());
                row.createCell(1).setCellValue(dto.getName());
                row.createCell(2).setCellValue(dto.getEmail());
                row.createCell(3).setCellValue(dto.getPolicyName());
                row.createCell(4).setCellValue(dto.getStatus());
            }

            workbook.write(out);
            return new ByteArrayInputStream(out.toByteArray());
        }
    }

    private ByteArrayInputStream generatePolicyPdf(List<PolicyReportDTO> data) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PdfWriter writer = new PdfWriter(out);
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf);

        document.add(new Paragraph("Policy Utilization Report"));

        Table table = new Table(4);
        table.addCell("Policy Name");
        table.addCell("Type");
        table.addCell("Enrollments");
        table.addCell("Total Premiums");

        for (PolicyReportDTO dto : data) {
            table.addCell(dto.getPolicyName());
            table.addCell(dto.getPolicyType());
            table.addCell(String.valueOf(dto.getEnrolledCount()));
            table.addCell(String.valueOf(dto.getTotalPremiums()));
        }

        document.add(table);
        document.close();

        return new ByteArrayInputStream(out.toByteArray());
    }

    private ByteArrayInputStream generatePolicyExcel(List<PolicyReportDTO> data) throws IOException {
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("Policies");

            Row headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("Policy Name");
            headerRow.createCell(1).setCellValue("Type");
            headerRow.createCell(2).setCellValue("Enrollments");
            headerRow.createCell(3).setCellValue("Total Premiums");

            int rowIdx = 1;
            for (PolicyReportDTO dto : data) {
                Row row = sheet.createRow(rowIdx++);
                row.createCell(0).setCellValue(dto.getPolicyName());
                row.createCell(1).setCellValue(dto.getPolicyType());
                row.createCell(2).setCellValue(dto.getEnrolledCount());
                row.createCell(3).setCellValue(dto.getTotalPremiums().doubleValue());
            }

            workbook.write(out);
            return new ByteArrayInputStream(out.toByteArray());
        }
    }

    private ByteArrayInputStream generateClaimPdf(List<ClaimReportDTO> data) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PdfWriter writer = new PdfWriter(out);
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf);

        document.add(new Paragraph("Claim Status Report"));

        Table table = new Table(6);
        table.addCell("ID");
        table.addCell("Employee");
        table.addCell("Policy");
        table.addCell("Amount");
        table.addCell("Status");
        table.addCell("Date");

        for (ClaimReportDTO dto : data) {
            table.addCell(String.valueOf(dto.getClaimId()));
            table.addCell(dto.getEmployeeName());
            table.addCell(dto.getPolicyName());
            table.addCell(String.valueOf(dto.getClaimAmount()));
            table.addCell(dto.getClaimStatus());
            table.addCell(String.valueOf(dto.getClaimDate()));
        }

        document.add(table);
        document.close();

        return new ByteArrayInputStream(out.toByteArray());
    }

    private ByteArrayInputStream generateClaimExcel(List<ClaimReportDTO> data) throws IOException {
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("Claims");

            Row headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("ID");
            headerRow.createCell(1).setCellValue("Employee");
            headerRow.createCell(2).setCellValue("Policy");
            headerRow.createCell(3).setCellValue("Amount");
            headerRow.createCell(4).setCellValue("Status");
            headerRow.createCell(5).setCellValue("Date");

            int rowIdx = 1;
            for (ClaimReportDTO dto : data) {
                Row row = sheet.createRow(rowIdx++);
                row.createCell(0).setCellValue(dto.getClaimId());
                row.createCell(1).setCellValue(dto.getEmployeeName());
                row.createCell(2).setCellValue(dto.getPolicyName());
                row.createCell(3).setCellValue(dto.getClaimAmount().doubleValue());
                row.createCell(4).setCellValue(dto.getClaimStatus());
                row.createCell(5).setCellValue(dto.getClaimDate().toString());
            }

            workbook.write(out);
            return new ByteArrayInputStream(out.toByteArray());
        }
    }
}
