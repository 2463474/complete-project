package com.example.ghim.service;

import com.example.ghim.entity.Employee;
import com.example.ghim.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService implements UserDetailsService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public Employee registerEmployee(Employee employee) {
        // Encode password before saving
        employee.setPassword(passwordEncoder.encode(employee.getPassword()));

        // Default role if none provided
        if (employee.getRole() == null || employee.getRole().isEmpty()) {
            employee.setRole("ROLE_EMPLOYEE");
        }
        return employeeRepository.save(employee);
    }

    public Employee getEmployeeByEmail(String email) {
        return employeeRepository.findByEmail(email);
    }

    public Employee updateEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    public Employee getEmployeeById(Long id) {
        return employeeRepository.findById(id).orElse(null);
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        Employee employee = employeeRepository.findByEmail(email);
        if (employee == null) {
            throw new UsernameNotFoundException("User not found with email: " + email);
        }

        // Remove ROLE_ prefix if it exists because builder adds it, or handle it
        // carefully.
        // Spring Security roles usually expect "USER", "ADMIN". If we store
        // "ROLE_ADMIN",
        // using .roles("ADMIN") adds "ROLE_", resulting in "ROLE_ROLE_ADMIN".
        // Using .authorities("ROLE_ADMIN") helps.
        // Let's stick to standard practice: Store "ROLE_ADMIN", use authorities.

        return org.springframework.security.core.userdetails.User.builder()
                .username(employee.getEmail())
                .password(employee.getPassword())
                .authorities(employee.getRole())
                .build();
    }
}
