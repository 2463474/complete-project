package com.example.ghim.service;

import com.example.ghim.entity.Claim;
import com.example.ghim.entity.Enrollment;
import com.example.ghim.repository.ClaimRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class ClaimService {

    @Autowired
    private ClaimRepository claimRepository;

    public Claim submitClaim(Claim claim) {
        claim.setClaimDate(LocalDate.now());
        claim.setClaimStatus(Claim.ClaimStatus.SUBMITTED);
        return claimRepository.save(claim);
    }

    public List<Claim> getClaimsByEnrollment(Enrollment enrollment) {
        return claimRepository.findByEnrollment(enrollment);
    }

    public List<Claim> getAllClaims() {
        return claimRepository.findAll();
    }

    public Claim getClaimById(Long id) {
        return claimRepository.findById(id).orElse(null);
    }

    public void updateClaimStatus(Long id, Claim.ClaimStatus status) {
        Claim claim = getClaimById(id);
        if (claim != null) {
            claim.setClaimStatus(status);
            claimRepository.save(claim);
        }
    }
}
