package com.example.ghim.controller;

import com.example.ghim.entity.Employee;
import com.example.ghim.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

@ControllerAdvice
public class GlobalControllerAdvice {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private com.example.ghim.service.NotificationService notificationService;

    @ModelAttribute("unreadNotifications")
    public java.util.List<com.example.ghim.entity.Notification> getUnreadNotifications() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.isAuthenticated() && !auth.getPrincipal().equals("anonymousUser")) {
            String email = auth.getName();
            Employee employee = employeeRepository.findByEmail(email);

            java.util.List<com.example.ghim.entity.Notification> notes = new java.util.ArrayList<>();

            // 1. Get role-based notifications (for Admin/HR)
            auth.getAuthorities().forEach(a -> {
                notes.addAll(notificationService.getUnreadForRole(a.getAuthority()));
            });

            // 2. Get user-specific notifications
            if (employee != null) {
                notes.addAll(notificationService.getUnreadForUser(employee.getEmployeeId()));
            }

            return notes;
        }
        return java.util.Collections.emptyList();
    }

    @ModelAttribute("currentUser")
    public Employee getCurrentUser() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.isAuthenticated() && !auth.getPrincipal().equals("anonymousUser")) {
            String email = auth.getName();
            Employee employee = employeeRepository.findByEmail(email);
            if (employee == null) {
                // Handle cases where email might not be in Employee table (e.g. default admin
                // with 'admin' username)
                // If it's the default admin, return a dummy object with name "Admin"
                if ("admin".equals(email)) {
                    Employee admin = new Employee();
                    admin.setName("Administrator");
                    return admin;
                }
            }
            return employee;
        }
        return null;
    }
}
