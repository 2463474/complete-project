package com.example.ghim.controller;

import com.example.ghim.entity.Claim;
import com.example.ghim.entity.Employee;
import com.example.ghim.entity.Enrollment;
import com.example.ghim.service.ClaimService;
import com.example.ghim.service.EmployeeService;
import com.example.ghim.service.EnrollmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

@Controller
public class ClaimController {

    @Autowired
    private ClaimService claimService;

    @Autowired
    private EnrollmentService enrollmentService;

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private com.example.ghim.service.NotificationService notificationService;

    // ---------------- EMPLOYEE ROUTES ---------------- //

    @GetMapping("/employee/claims")
    public String myClaims(Model model, Principal principal) {
        Employee employee = employeeService.getEmployeeByEmail(principal.getName());
        List<Enrollment> enrollments = enrollmentService.getEnrollmentsByEmployee(employee);

        // Fetch notifications
        List<com.example.ghim.entity.Notification> notifications = notificationService
                .getUnreadForUser(employee.getEmployeeId());
        model.addAttribute("notifications", notifications);

        List<Claim> allClaims = new ArrayList<>();
        for (Enrollment e : enrollments) {
            allClaims.addAll(claimService.getClaimsByEnrollment(e));
        }

        model.addAttribute("claims", allClaims);
        return "my-claims";
    }

    @GetMapping("/employee/claims/new")
    public String showClaimForm(@RequestParam(required = false) Long enrollmentId, Model model, Principal principal) {
        Employee employee = employeeService.getEmployeeByEmail(principal.getName());
        List<Enrollment> activeEnrollments = enrollmentService.getEnrollmentsByEmployee(employee)
                .stream()
                .filter(e -> e.getStatus() == Enrollment.Status.ACTIVE)
                .toList();

        model.addAttribute("selectedEnrollmentId", enrollmentId);

        if (activeEnrollments.isEmpty()) {
            return "redirect:/employee/enrollments?noActiveEnrollments";
        }

        model.addAttribute("claim", new Claim());
        model.addAttribute("enrollments", activeEnrollments);
        return "claim-form";
    }

    @PostMapping("/employee/claims/submit")
    public String submitClaim(@jakarta.validation.Valid @ModelAttribute Claim claim,
            org.springframework.validation.BindingResult result,
            @RequestParam Long enrollmentId,
            Model model,
            Principal principal) {
        if (result.hasErrors()) {
            Employee employee = employeeService.getEmployeeByEmail(principal.getName());
            List<Enrollment> activeEnrollments = enrollmentService.getEnrollmentsByEmployee(employee)
                    .stream()
                    .filter(e -> e.getStatus() == Enrollment.Status.ACTIVE)
                    .toList();
            model.addAttribute("enrollments", activeEnrollments);
            return "claim-form";
        }
        Enrollment enrollment = enrollmentService.getEnrollmentById(enrollmentId);

        // Security Check: Ensure enrollment belongs to current user
        Employee employee = employeeService.getEmployeeByEmail(principal.getName());
        if (enrollment == null || !enrollment.getEmployee().getEmployeeId().equals(employee.getEmployeeId())) {
            throw new IllegalArgumentException("Invalid Policy Enrollment ID or Unauthorized Access");
        }
        claim.setEnrollment(enrollment);
        Claim saved = claimService.submitClaim(claim);

        // Notify Admin
        notificationService.createRoleNotification("ROLE_ADMIN",
                "New Claim Submitted by " + enrollment.getEmployee().getName() + " (ID: " + saved.getClaimId() + ")");

        return "redirect:/employee/claims";
    }

    // ---------------- ADMIN ROUTES ---------------- //

    @GetMapping("/admin/claims")
    public String manageClaims(Model model) {
        // Fetch notifications
        List<com.example.ghim.entity.Notification> notifications = notificationService.getUnreadForRole("ROLE_ADMIN");
        model.addAttribute("notifications", notifications);
        model.addAttribute("claims", claimService.getAllClaims());
        return "admin-claims";
    }

    @PostMapping("/admin/claims/update")
    public String updateStatus(@RequestParam Long claimId,
            @RequestParam String status,
            @RequestParam(required = false) String rejectionReason) {
        Claim.ClaimStatus newStatus = Claim.ClaimStatus.valueOf(status);

        // Handle Logic
        Claim claim = claimService.getClaimById(claimId);
        if (claim != null) {
            claim.setClaimStatus(newStatus);
            if (newStatus == Claim.ClaimStatus.REJECTED && rejectionReason != null) {
                claim.setRejectionReason(rejectionReason);
            }
            claimService.submitClaim(claim); // save

            // Notify Employee
            Long empId = claim.getEnrollment().getEmployee().getEmployeeId();
            String msg = "Your Claim #" + claimId + " has been " + newStatus;
            if (newStatus == Claim.ClaimStatus.REJECTED) {
                msg += ". Reason: " + rejectionReason;
            }
            notificationService.createNotification(empId, msg);
        }
        return "redirect:/admin/claims";
    }

    @PostMapping("/notifications/read")
    public String markRead(@RequestParam Long id, @RequestParam String redirect) {
        notificationService.markAsRead(id);
        return "redirect:" + redirect;
    }
}
