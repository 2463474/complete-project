package com.example.ghim.service;

import com.example.ghim.entity.Notification;
import com.example.ghim.repository.NotificationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class NotificationService {

    @Autowired
    private NotificationRepository notificationRepository;

    public void createNotification(Long userId, String message) {
        Notification n = new Notification();
        n.setUserId(userId);
        n.setMessage(message);
        n.setCreatedDate(LocalDateTime.now());
        notificationRepository.save(n);
    }

    public void createRoleNotification(String role, String message) {
        Notification n = new Notification();
        n.setTargetRole(role);
        n.setMessage(message);
        n.setCreatedDate(LocalDateTime.now());
        notificationRepository.save(n);
    }

    public List<Notification> getUnreadForUser(Long userId) {
        return notificationRepository.findByUserIdAndIsReadFalse(userId);
    }

    // Getting Role notifications is trickier since multiple admins see same row?
    // For simplicity: Admin notifications are global. We won't mark them generic
    // read per user.
    // Or we find by targetRole.
    public List<Notification> getUnreadForRole(String role) {
        return notificationRepository.findByTargetRoleAndIsReadFalse(role);
    }

    public void markAsRead(Long id) {
        notificationRepository.findById(id).ifPresent(n -> {
            n.setRead(true);
            notificationRepository.save(n);
        });
    }
}
