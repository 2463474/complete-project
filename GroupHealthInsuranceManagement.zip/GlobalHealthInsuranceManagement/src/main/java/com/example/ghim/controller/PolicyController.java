package com.example.ghim.controller;

import com.example.ghim.entity.Policy;
import com.example.ghim.service.PolicyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class PolicyController {

    @Autowired
    private PolicyService policyService;

    // View for Employees to see available policies
    @GetMapping("/policies")
    public String listPolicies(Model model) {
        model.addAttribute("policies", policyService.getAllPolicies());
        return "policy-list";
    }

    // Admin: List Policies (Manage)
    @GetMapping("/admin/policies")
    public String managePolicies(Model model) {
        model.addAttribute("policies", policyService.getAllPolicies());
        return "admin-policies";
    }

    // Admin: Create Form
    @GetMapping("/admin/policies/new")
    public String createPolicyForm(Model model) {
        model.addAttribute("policy", new Policy());
        return "policy-form";
    }

    @PostMapping("/admin/policies/save")
    public String savePolicy(@ModelAttribute Policy policy) {
        policyService.savePolicy(policy);
        return "redirect:/admin/policies";
    }
}
