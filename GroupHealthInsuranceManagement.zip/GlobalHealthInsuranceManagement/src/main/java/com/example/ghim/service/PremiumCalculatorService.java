package com.example.ghim.service;

import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import com.example.ghim.entity.Policy;

@Service
public class PremiumCalculatorService {

    public BigDecimal calculatePremium(Policy policy, int age, int dependents) {
        BigDecimal basePremium = policy.getPremiumAmount();

        // Example Algorithm:
        // 1. Age Factor: +2% for every year above 25
        BigDecimal ageFactor = BigDecimal.ZERO;
        if (age > 25)
            ageFactor = basePremium.multiply(BigDecimal.valueOf((age - 25) * 0.02));

        // 2. Dependent Factor: +₹500 per dependent
        BigDecimal dependentCost = BigDecimal.valueOf(dependents * 500);

        return basePremium.add(ageFactor).add(dependentCost);
    }
}
