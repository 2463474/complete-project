package com.example.ghim.service;

import com.example.ghim.entity.Enrollment;
import com.example.ghim.entity.Employee;
import com.example.ghim.entity.Policy;
import com.example.ghim.repository.EnrollmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class EnrollmentService {

    @Autowired
    private EnrollmentRepository enrollmentRepository;

    public Enrollment enroll(Employee employee, Policy policy) {
        // Business Rule: Check if already enrolled in same policy?
        // For simplicity, we just save a new one.

        Enrollment enrollment = new Enrollment();
        enrollment.setEmployee(employee);
        enrollment.setPolicy(policy);
        enrollment.setEnrollmentDate(LocalDate.now());
        enrollment.setStatus(Enrollment.Status.ACTIVE);

        return enrollmentRepository.save(enrollment);
    }

    public List<Enrollment> getEnrollmentsByEmployee(Employee employee) {
        return enrollmentRepository.findByEmployee(employee);
    }

    public Enrollment getEnrollmentById(Long id) {
        return enrollmentRepository.findById(id).orElse(null);
    }

    public void cancelEnrollment(Long id) {
        Enrollment enrollment = getEnrollmentById(id);
        if (enrollment != null) {
            enrollment.setStatus(Enrollment.Status.CANCELLED);
            enrollmentRepository.save(enrollment);
        }
    }

    public Enrollment saveEnrollment(Enrollment enrollment) {
        return enrollmentRepository.save(enrollment);
    }
}
