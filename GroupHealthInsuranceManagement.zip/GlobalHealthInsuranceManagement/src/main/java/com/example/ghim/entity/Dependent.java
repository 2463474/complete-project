package com.example.ghim.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name = "Dependent")
public class Dependent {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long dependentId;

    private String name;
    private Integer age;
    private String relationship; // FATHER or MOTHER

    // No direct FK here for simplicity, or we can add Enrollment ID.
    // It's cleaner to have Enrollment OneToMany Dependent.
    // But JPA needs a join column.
}
