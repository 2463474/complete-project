package com.example.ghim.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDate;

@Entity
@Data
@Table(name = "Enrollment")
public class Enrollment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long enrollmentId;

    @ManyToOne
    @JoinColumn(name = "employeeId", nullable = false)
    @jakarta.validation.constraints.NotNull(message = "Employee is required")
    private Employee employee;

    @ManyToOne
    @JoinColumn(name = "policyId", nullable = false)
    @jakarta.validation.constraints.NotNull(message = "Policy is required")
    private Policy policy;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "enrollment_id") // Unidirectional
    private java.util.List<Dependent> dependents = new java.util.ArrayList<>();

    private LocalDate enrollmentDate;

    private java.math.BigDecimal totalPremium;

    @Enumerated(EnumType.STRING)
    private Status status;

    public enum Status {
        ACTIVE, CANCELLED
    }
}
