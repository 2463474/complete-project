package com.example.ghim.controller;

import com.example.ghim.entity.Policy;
import com.example.ghim.service.PolicyService;
import com.example.ghim.service.PremiumCalculatorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.math.BigDecimal;

@Controller
public class PremiumCalculatorController {

    @Autowired
    private PremiumCalculatorService calculatorService;

    @Autowired
    private PolicyService policyService;

    @GetMapping("/calculator")
    public String showCalculator(Model model) {
        model.addAttribute("policies", policyService.getAllPolicies());
        return "premium-calculator";
    }

    @PostMapping("/calculator/calculate")
    public String calculatePremium(
            @RequestParam Long policyId,
            @RequestParam int age,
            @RequestParam int dependents,
            Model model) {

        Policy policy = policyService.getPolicyById(policyId);
        BigDecimal result = calculatorService.calculatePremium(policy, age, dependents);

        model.addAttribute("policies", policyService.getAllPolicies());
        model.addAttribute("result", result);
        model.addAttribute("selectedPolicy", policy);
        model.addAttribute("inputAge", age);
        model.addAttribute("inputDependents", dependents);

        return "premium-calculator";
    }
}
