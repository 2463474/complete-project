package com.example.ghim.controller;

import com.example.ghim.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller; // Compatible with Thymeleaf
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.security.Principal;

@Controller
@RequestMapping("/reports")
public class ReportController {

    @Autowired
    private ReportService reportService;

    @GetMapping("")
    public String reportsDashboard() {
        return "reports-dashboard";
    }

    @GetMapping("/employee")
    public String generateEmployeeReport(Model model) {
        // Prepares data for Thymeleaf view
        model.addAttribute("reportData", reportService.generateEmployeeReport());
        return "employee-report"; // Logical view name
    }

    // You can add generatePolicyReport similarly
    @GetMapping("/policy")
    public String generatePolicyReport(Model model) {
        model.addAttribute("reportData", reportService.generatePolicyReport());
        return "policy-report";
    }

    @GetMapping("/claim")
    public String generateClaimReport(Model model) {
        model.addAttribute("reportData", reportService.generateClaimReport());
        return "claim-report";
    }

    @GetMapping("/export")
    public ResponseEntity<InputStreamResource> exportReport(
            @RequestParam String type,
            @RequestParam String format) throws IOException {

        ByteArrayInputStream in = reportService.exportReport(type, format);

        String extension = "PDF".equalsIgnoreCase(format) ? "pdf" : "xlsx";
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition",
                "attachment; filename=" + type.toLowerCase() + "_report." + extension);

        MediaType mediaType = "PDF".equalsIgnoreCase(format) ? MediaType.APPLICATION_PDF
                : MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

        return ResponseEntity
                .ok()
                .headers(headers)
                .contentType(mediaType)
                .body(new InputStreamResource(in));
    }

    @GetMapping("/my-report")
    public String generateUserReport(Model model, Principal principal) {
        String email = principal.getName();
        // Fallback for default 'user' if needed or let it fail if not found
        model.addAttribute("reportData", reportService.generateUserInsuranceReport(email));
        return "user-insurance-report";
    }

    @GetMapping("/export/my-report")
    public ResponseEntity<InputStreamResource> exportUserReport(
            @RequestParam String format,
            Principal principal) throws IOException {

        String email = principal.getName();
        ByteArrayInputStream in = reportService.exportUserReport(email, format);

        String extension = "PDF".equalsIgnoreCase(format) ? "pdf" : "xlsx";
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition",
                "attachment; filename=my_insurance_report." + extension);

        MediaType mediaType = "PDF".equalsIgnoreCase(format) ? MediaType.APPLICATION_PDF
                : MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

        return ResponseEntity
                .ok()
                .headers(headers)
                .contentType(mediaType)
                .body(new InputStreamResource(in));
    }
}
