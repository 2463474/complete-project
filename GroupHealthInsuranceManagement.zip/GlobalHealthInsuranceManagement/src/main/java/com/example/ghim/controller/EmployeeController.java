package com.example.ghim.controller;

import com.example.ghim.entity.Employee;
import com.example.ghim.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.security.Principal;

@Controller
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @GetMapping("/register")
    public String showRegisterForm(Model model) {
        model.addAttribute("employee", new Employee());
        return "register-employee";
    }

    @PostMapping("/register")
    public String registerEmployee(@Valid @ModelAttribute Employee employee, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "register-employee";
        }
        try {
            employeeService.registerEmployee(employee);
        } catch (Exception e) {
            model.addAttribute("error", "Registration failed: " + e.getMessage());
            return "register-employee";
        }
        return "redirect:/login?registered";
    }

    @GetMapping("/employee/profile")
    public String getEmployeeDetails(Model model, Principal principal) {
        if (principal == null)
            return "redirect:/login";
        String email = principal.getName();
        Employee employee = employeeService.getEmployeeByEmail(email);
        model.addAttribute("employee", employee);
        return "employee-profile";
    }

    @PostMapping("/employee/update")
    public String updateEmployeeProfile(@ModelAttribute Employee employee) {
        // Important: Ensure we don't overwrite password/role if not present in form
        // For simplicity, assuming service handles update or form has hidden fields
        // In a real app, fetch existing, update allowed fields, and save.

        Employee existing = employeeService.getEmployeeById(employee.getEmployeeId());
        if (existing != null) {
            existing.setPhone(employee.getPhone());
            existing.setAddress(employee.getAddress());
            // Update other non-sensitive fields
            employeeService.updateEmployee(existing);
        }

        return "redirect:/employee/profile?updated";
    }
}
