package com.example.ghim.controller;

import com.example.ghim.entity.Employee;
import com.example.ghim.entity.Enrollment;
import com.example.ghim.entity.Policy;
import com.example.ghim.service.EmployeeService;
import com.example.ghim.service.EnrollmentService;
import com.example.ghim.service.PolicyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.ghim.entity.Dependent;
import java.math.BigDecimal;
import java.security.Principal;
import java.util.List;
import java.util.ArrayList;

@Controller
public class EnrollmentController {

    @Autowired
    private EnrollmentService enrollmentService;

    @Autowired
    private PolicyService policyService;

    @Autowired
    private EmployeeService employeeService;

    // View My Enrollments
    @GetMapping("/employee/enrollments")
    public String myEnrollments(Model model, Principal principal) {
        Employee employee = employeeService.getEmployeeByEmail(principal.getName());
        List<Enrollment> enrollments = enrollmentService.getEnrollmentsByEmployee(employee);
        model.addAttribute("enrollments", enrollments);
        return "my-enrollments";
    }

    // Show Enrollment Form
    @GetMapping("/employee/enroll/new")
    public String showEnrollForm(@RequestParam Long policyId, Model model) {
        Policy policy = policyService.getPolicyById(policyId);
        model.addAttribute("policy", policy);
        return "enrollment-form";
    }

    // Process Enrollment with Dependents
    @PostMapping("/employee/enroll")
    public String enrollInPolicy(@RequestParam Long policyId,
            @RequestParam(required = false) String spouseName,
            @RequestParam(required = false) Integer spouseAge,
            @RequestParam(required = false) String fatherName,
            @RequestParam(required = false) Integer fatherAge,
            @RequestParam(required = false) String motherName,
            @RequestParam(required = false) Integer motherAge,
            @RequestParam(name = "childNames[]", required = false) List<String> childNames,
            @RequestParam(name = "childAges[]", required = false) List<Integer> childAges,
            Principal principal) {
        Employee employee = employeeService.getEmployeeByEmail(principal.getName());
        Policy policy = policyService.getPolicyById(policyId);

        if (policy != null) {
            Enrollment enrollment = new Enrollment();
            enrollment.setEmployee(employee);
            enrollment.setPolicy(policy);
            enrollment.setEnrollmentDate(java.time.LocalDate.now());
            enrollment.setStatus(Enrollment.Status.ACTIVE);

            BigDecimal totalPremium = policy.getPremiumAmount();
            List<Dependent> dependents = new ArrayList<>();

            // Handle Spouse
            if (spouseName != null && !spouseName.trim().isEmpty()) {
                Dependent spouse = new Dependent();
                spouse.setName(spouseName);
                spouse.setAge(spouseAge);
                spouse.setRelationship("WIFE/SPOUSE");
                dependents.add(spouse);
                totalPremium = totalPremium.add(new BigDecimal("200.00"));
            }

            // Handle Father
            if (fatherName != null && !fatherName.trim().isEmpty()) {
                Dependent father = new Dependent();
                father.setName(fatherName);
                father.setAge(fatherAge);
                father.setRelationship("FATHER");
                dependents.add(father);
                totalPremium = totalPremium.add(new BigDecimal("300.00"));
            }

            // Handle Mother
            if (motherName != null && !motherName.trim().isEmpty()) {
                Dependent mother = new Dependent();
                mother.setName(motherName);
                mother.setAge(motherAge);
                mother.setRelationship("MOTHER");
                dependents.add(mother);
                totalPremium = totalPremium.add(new BigDecimal("300.00"));
            }

            // Handle Children
            if (childNames != null) {
                for (int i = 0; i < childNames.size(); i++) {
                    String cName = childNames.get(i);
                    if (cName != null && !cName.trim().isEmpty()) {
                        Dependent child = new Dependent();
                        child.setName(cName);
                        child.setAge(childAges.get(i));
                        child.setRelationship("CHILD");
                        dependents.add(child);
                        totalPremium = totalPremium.add(new BigDecimal("150.00"));
                    }
                }
            }

            enrollment.setDependents(dependents);
            enrollment.setTotalPremium(totalPremium);
            enrollmentService.saveEnrollment(enrollment);
        }

        return "redirect:/employee/enrollments";
    }

    // Cancel Action
    @PostMapping("/employee/enrollments/cancel")
    public String cancelEnrollment(@RequestParam Long enrollmentId) {
        enrollmentService.cancelEnrollment(enrollmentId);
        return "redirect:/employee/enrollments";
    }
}
