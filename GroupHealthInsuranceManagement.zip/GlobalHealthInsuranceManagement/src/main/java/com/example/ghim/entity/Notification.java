package com.example.ghim.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

@Entity
@Data
@Table(name = "Notification")
public class Notification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long userId; // The ID of the generic user (Employee PK)

    private String message;

    // For role-based notifications (e.g. notify all admins)
    private String targetRole; // e.g., ROLE_ADMIN

    private boolean isRead = false;

    private LocalDateTime createdDate;
}
