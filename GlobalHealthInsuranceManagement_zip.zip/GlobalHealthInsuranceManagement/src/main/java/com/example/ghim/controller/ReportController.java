package com.example.ghim.controller;

import com.example.ghim.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller; // Compatible with Thymeleaf
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.ByteArrayInputStream;
import java.io.IOException;

@Controller
@RequestMapping("/reports")
public class ReportController {

    @Autowired
    private ReportService reportService;

    @GetMapping("/employee")
    public String generateEmployeeReport(Model model) {
        // Prepares data for Thymeleaf view
        model.addAttribute("reportData", reportService.generateEmployeeReport());
        return "employee-report"; // Logical view name
    }

    // You can add generatePolicyReport similarly
    @GetMapping("/policy")
    public String generatePolicyReport(Model model) {
        // Placeholder for policy report
        // model.addAttribute("reportData", reportService.generatePolicyReport());
        return "policy-report";
    }

    @GetMapping("/export")
    public ResponseEntity<InputStreamResource> exportReport(
            @RequestParam String type,
            @RequestParam String format) throws IOException {

        ByteArrayInputStream in = reportService.exportReport(type, format);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition",
                "attachment; filename=" + type.toLowerCase() + "_report." + format.toLowerCase());

        MediaType mediaType = "PDF".equalsIgnoreCase(format) ? MediaType.APPLICATION_PDF
                : MediaType.APPLICATION_OCTET_STREAM;

        return ResponseEntity
                .ok()
                .headers(headers)
                .contentType(mediaType)
                .body(new InputStreamResource(in));
    }
}
