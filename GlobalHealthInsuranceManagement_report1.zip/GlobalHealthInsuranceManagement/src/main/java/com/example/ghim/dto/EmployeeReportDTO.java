package com.example.ghim.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeReportDTO {
    private Long employeeId;
    private String name;
    private String email;
    private String policyName;
    private String status;
}
