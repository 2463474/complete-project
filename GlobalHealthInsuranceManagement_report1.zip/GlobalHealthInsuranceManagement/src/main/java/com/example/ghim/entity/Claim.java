package com.example.ghim.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Data
@Table(name = "Claim")
public class Claim {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long claimId;

    @ManyToOne
    @JoinColumn(name = "enrollmentId", nullable = false)
    private Enrollment enrollment;

    @DecimalMin(value = "0.0", inclusive = false, message = "Claim amount must be positive")
    private BigDecimal claimAmount;

    @NotBlank(message = "Claim reason is required")
    private String claimReason;

    private LocalDate claimDate;

    @Enumerated(EnumType.STRING)
    private ClaimStatus claimStatus;

    public enum ClaimStatus {
        SUBMITTED, APPROVED, REJECTED
    }
}
