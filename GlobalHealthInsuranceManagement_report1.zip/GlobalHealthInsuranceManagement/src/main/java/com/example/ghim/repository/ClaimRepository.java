package com.example.ghim.repository;

import com.example.ghim.entity.Claim;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ClaimRepository extends JpaRepository<Claim, Long> {
    java.util.List<Claim> findByEnrollment(com.example.ghim.entity.Enrollment enrollment);
}
