package com.example.ghim.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserInsuranceReportDTO {
    private String employeeName;
    private String email;
    private String phone;
    private List<UserEnrollmentDTO> enrollments;
}
