package com.example.ghim.repository;

import com.example.ghim.entity.Enrollment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EnrollmentRepository extends JpaRepository<Enrollment, Long> {
    java.util.List<Enrollment> findByEmployee(com.example.ghim.entity.Employee employee);
}
