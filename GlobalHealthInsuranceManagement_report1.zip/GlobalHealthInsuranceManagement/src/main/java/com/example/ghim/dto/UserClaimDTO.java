package com.example.ghim.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserClaimDTO {
    private Long claimId;
    private LocalDate claimDate;
    private String claimReason;
    private BigDecimal claimAmount;
    private String status;
}
