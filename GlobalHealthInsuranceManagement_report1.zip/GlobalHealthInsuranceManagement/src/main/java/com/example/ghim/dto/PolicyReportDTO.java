package com.example.ghim.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PolicyReportDTO {
    private String policyName;
    private String policyType;
    private Long enrolledCount;
    private BigDecimal totalPremiums;
}
