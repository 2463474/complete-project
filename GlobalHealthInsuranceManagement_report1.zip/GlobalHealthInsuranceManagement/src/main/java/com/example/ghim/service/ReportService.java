package com.example.ghim.service;

import com.example.ghim.dto.EmployeeReportDTO;
import com.example.ghim.dto.PolicyReportDTO;
import com.example.ghim.dto.ClaimReportDTO;
import com.example.ghim.dto.UserInsuranceReportDTO;
import com.example.ghim.dto.UserEnrollmentDTO;
import com.example.ghim.dto.UserClaimDTO;
import com.example.ghim.entity.Employee;
import com.example.ghim.entity.Enrollment;
import com.example.ghim.entity.Policy;
import com.example.ghim.entity.Claim;
import com.example.ghim.repository.EmployeeRepository;
import com.example.ghim.repository.EnrollmentRepository;
import com.example.ghim.repository.PolicyRepository;
import com.example.ghim.repository.ClaimRepository;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.math.BigDecimal;

@Service
public class ReportService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private EnrollmentRepository enrollmentRepository;

    @Autowired
    private PolicyRepository policyRepository;

    @Autowired
    private ClaimRepository claimRepository;

    // Generates data for Employee Report
    public List<EmployeeReportDTO> generateEmployeeReport() {
        // In a real scenario, this would likely be a complex query.
        // For now, we simulate fetching enrolled employees.
        List<Enrollment> enrollments = enrollmentRepository.findAll();

        return enrollments.stream().map(enrollment -> {
            Employee emp = enrollment.getEmployee();
            return new EmployeeReportDTO(
                    emp.getEmployeeId(),
                    emp.getName(),
                    emp.getEmail(),
                    enrollment.getPolicy().getPolicyName(),
                    enrollment.getStatus().name());
        }).collect(Collectors.toList());
    }

    public List<PolicyReportDTO> generatePolicyReport() {
        List<Policy> policies = policyRepository.findAll();
        List<Enrollment> enrollments = enrollmentRepository.findAll();

        return policies.stream().map(policy -> {
            long count = enrollments.stream()
                    .filter(e -> e.getPolicy().getPolicyId().equals(policy.getPolicyId()) &&
                            "ACTIVE".equals(e.getStatus().name()))
                    .count();
            BigDecimal totalPremium = policy.getPremiumAmount().multiply(BigDecimal.valueOf(count));
            return new PolicyReportDTO(policy.getPolicyName(), policy.getPolicyType().name(), count, totalPremium);
        }).collect(Collectors.toList());
    }

    public List<ClaimReportDTO> generateClaimReport() {
        return claimRepository.findAll().stream().map(claim -> new ClaimReportDTO(
                claim.getClaimId(),
                claim.getEnrollment().getEmployee().getName(),
                claim.getEnrollment().getPolicy().getPolicyName(),
                claim.getClaimAmount(),
                claim.getClaimStatus().name(),
                claim.getClaimDate())).collect(Collectors.toList());
    }

    public UserInsuranceReportDTO generateUserInsuranceReport(String email) {
        Employee employee = employeeRepository.findByEmail(email);
        if (employee == null) {
            throw new RuntimeException("Employee not found for email: " + email);
        }

        List<Enrollment> enrollments = enrollmentRepository.findByEmployee(employee);
        List<UserEnrollmentDTO> enrollmentDTOs = enrollments.stream().map(enrollment -> {
            List<Claim> claims = claimRepository.findByEnrollment(enrollment);
            List<UserClaimDTO> claimDTOs = claims.stream().map(claim -> new UserClaimDTO(
                    claim.getClaimId(),
                    claim.getClaimDate(),
                    claim.getClaimReason(),
                    claim.getClaimAmount(),
                    claim.getClaimStatus().name())).collect(Collectors.toList());

            return new UserEnrollmentDTO(
                    enrollment.getPolicy().getPolicyName(),
                    enrollment.getPolicy().getPolicyType().name(),
                    enrollment.getEnrollmentDate(),
                    enrollment.getStatus().name(),
                    enrollment.getPolicy().getPremiumAmount(),
                    claimDTOs);
        }).collect(Collectors.toList());

        return new UserInsuranceReportDTO(
                employee.getName(),
                employee.getEmail(),
                employee.getPhone(),
                enrollmentDTOs);
    }

    // Export Logic
    public ByteArrayInputStream exportReport(String reportType, String format) throws IOException {
        if ("EMPLOYEE".equalsIgnoreCase(reportType)) {
            List<EmployeeReportDTO> data = generateEmployeeReport();
            if ("PDF".equalsIgnoreCase(format)) {
                return generateEmployeePdf(data);
            } else if ("EXCEL".equalsIgnoreCase(format)) {
                return generateEmployeeExcel(data);
            }
        } else if ("POLICY".equalsIgnoreCase(reportType)) {
            List<PolicyReportDTO> data = generatePolicyReport();
            if ("PDF".equalsIgnoreCase(format)) {
                return generatePolicyPdf(data);
            } else if ("EXCEL".equalsIgnoreCase(format)) {
                return generatePolicyExcel(data);
            }
        } else if ("CLAIM".equalsIgnoreCase(reportType)) {
            List<ClaimReportDTO> data = generateClaimReport();
            if ("PDF".equalsIgnoreCase(format)) {
                return generateClaimPdf(data);
            } else if ("EXCEL".equalsIgnoreCase(format)) {
                return generateClaimExcel(data);
            }
        }
        // Add other report types here
        throw new IllegalArgumentException("Unsupported report type or format");
    }

    private ByteArrayInputStream generateEmployeePdf(List<EmployeeReportDTO> data) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PdfWriter writer = new PdfWriter(out);
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf);

        document.add(new Paragraph("Employee Enrollment Report"));

        Table table = new Table(5);
        table.addCell("ID");
        table.addCell("Name");
        table.addCell("Email");
        table.addCell("Policy");
        table.addCell("Status");

        for (EmployeeReportDTO dto : data) {
            table.addCell(String.valueOf(dto.getEmployeeId()));
            table.addCell(dto.getName());
            table.addCell(dto.getEmail());
            table.addCell(dto.getPolicyName());
            table.addCell(dto.getStatus());
        }

        document.add(table);
        document.close();

        return new ByteArrayInputStream(out.toByteArray());
    }

    private ByteArrayInputStream generateEmployeeExcel(List<EmployeeReportDTO> data) throws IOException {
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("Employees");

            Row headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("ID");
            headerRow.createCell(1).setCellValue("Name");
            headerRow.createCell(2).setCellValue("Email");
            headerRow.createCell(3).setCellValue("Policy");
            headerRow.createCell(4).setCellValue("Status");

            int rowIdx = 1;
            for (EmployeeReportDTO dto : data) {
                Row row = sheet.createRow(rowIdx++);
                row.createCell(0).setCellValue(dto.getEmployeeId());
                row.createCell(1).setCellValue(dto.getName());
                row.createCell(2).setCellValue(dto.getEmail());
                row.createCell(3).setCellValue(dto.getPolicyName());
                row.createCell(4).setCellValue(dto.getStatus());
            }

            workbook.write(out);
            return new ByteArrayInputStream(out.toByteArray());
        }
    }

    private ByteArrayInputStream generatePolicyPdf(List<PolicyReportDTO> data) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PdfWriter writer = new PdfWriter(out);
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf);

        document.add(new Paragraph("Policy Utilization Report"));

        Table table = new Table(4);
        table.addCell("Policy Name");
        table.addCell("Type");
        table.addCell("Enrollments");
        table.addCell("Total Premiums");

        for (PolicyReportDTO dto : data) {
            table.addCell(dto.getPolicyName());
            table.addCell(dto.getPolicyType());
            table.addCell(String.valueOf(dto.getEnrolledCount()));
            table.addCell(String.valueOf(dto.getTotalPremiums()));
        }

        document.add(table);
        document.close();

        return new ByteArrayInputStream(out.toByteArray());
    }

    private ByteArrayInputStream generatePolicyExcel(List<PolicyReportDTO> data) throws IOException {
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("Policies");

            Row headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("Policy Name");
            headerRow.createCell(1).setCellValue("Type");
            headerRow.createCell(2).setCellValue("Enrollments");
            headerRow.createCell(3).setCellValue("Total Premiums");

            int rowIdx = 1;
            for (PolicyReportDTO dto : data) {
                Row row = sheet.createRow(rowIdx++);
                row.createCell(0).setCellValue(dto.getPolicyName());
                row.createCell(1).setCellValue(dto.getPolicyType());
                row.createCell(2).setCellValue(dto.getEnrolledCount());
                row.createCell(3).setCellValue(dto.getTotalPremiums().doubleValue());
            }

            workbook.write(out);
            return new ByteArrayInputStream(out.toByteArray());
        }
    }

    private ByteArrayInputStream generateClaimPdf(List<ClaimReportDTO> data) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PdfWriter writer = new PdfWriter(out);
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf);

        document.add(new Paragraph("Claim Status Report"));

        Table table = new Table(6);
        table.addCell("ID");
        table.addCell("Employee");
        table.addCell("Policy");
        table.addCell("Amount");
        table.addCell("Status");
        table.addCell("Date");

        for (ClaimReportDTO dto : data) {
            table.addCell(String.valueOf(dto.getClaimId()));
            table.addCell(dto.getEmployeeName());
            table.addCell(dto.getPolicyName());
            table.addCell(String.valueOf(dto.getClaimAmount()));
            table.addCell(dto.getClaimStatus());
            table.addCell(String.valueOf(dto.getClaimDate()));
        }
        document.add(table);
        document.close();

        return new ByteArrayInputStream(out.toByteArray());
    }

    private ByteArrayInputStream generateClaimExcel(List<ClaimReportDTO> data) throws IOException {
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("Claims");

            Row headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("ID");
            headerRow.createCell(1).setCellValue("Employee");
            headerRow.createCell(2).setCellValue("Policy");
            headerRow.createCell(3).setCellValue("Amount");
            headerRow.createCell(4).setCellValue("Status");
            headerRow.createCell(5).setCellValue("Date");

            int rowIdx = 1;
            for (ClaimReportDTO dto : data) {
                Row row = sheet.createRow(rowIdx++);
                row.createCell(0).setCellValue(dto.getClaimId());
                row.createCell(1).setCellValue(dto.getEmployeeName());
                row.createCell(2).setCellValue(dto.getPolicyName());
                row.createCell(3).setCellValue(dto.getClaimAmount().doubleValue());
                row.createCell(4).setCellValue(dto.getClaimStatus());
                row.createCell(5).setCellValue(dto.getClaimDate().toString());
            }

            workbook.write(out);
            return new ByteArrayInputStream(out.toByteArray());
        }
    }

    public ByteArrayInputStream exportUserReport(String email, String format) throws IOException {
        UserInsuranceReportDTO data = generateUserInsuranceReport(email);
        if ("PDF".equalsIgnoreCase(format)) {
            return generateUserPdf(data);
        } else if ("EXCEL".equalsIgnoreCase(format)) {
            return generateUserExcel(data);
        }
        throw new IllegalArgumentException("Unsupported format");
    }

    private ByteArrayInputStream generateUserPdf(UserInsuranceReportDTO data) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PdfWriter writer = new PdfWriter(out);
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf);

        document.add(new Paragraph("Personal Insurance Report").setFontSize(18));
        document.add(new Paragraph("Name: " + data.getEmployeeName()));
        document.add(new Paragraph("Email: " + data.getEmail()));

        for (UserEnrollmentDTO enrollment : data.getEnrollments()) {
            document.add(new Paragraph("\nPolicy: " + enrollment.getPolicyName() + " (" + enrollment.getStatus() + ")")
                    .setBold());
            document.add(new Paragraph(
                    "Type: " + enrollment.getPolicyType() + " | Premium: " + enrollment.getPremiumAmount()));

            if (enrollment.getClaims() != null && !enrollment.getClaims().isEmpty()) {
                document.add(new Paragraph("Claims:"));
                Table table = new Table(4);
                table.addCell("Date");
                table.addCell("Reason");
                table.addCell("Amount");
                table.addCell("Status");

                for (UserClaimDTO claim : enrollment.getClaims()) {
                    table.addCell(claim.getClaimDate().toString());
                    table.addCell(claim.getClaimReason());
                    table.addCell(String.valueOf(claim.getClaimAmount()));
                    table.addCell(claim.getStatus());
                }
                document.add(table);
            } else {
                document.add(new Paragraph("No claims submitted for this policy."));
            }
        }

        document.close();
        return new ByteArrayInputStream(out.toByteArray());
    }

    private ByteArrayInputStream generateUserExcel(UserInsuranceReportDTO data) throws IOException {
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("My Insurance");

            int rowIdx = 0;
            Row titleRow = sheet.createRow(rowIdx++);
            titleRow.createCell(0).setCellValue("Personal Insurance Report for " + data.getEmployeeName());

            rowIdx++; // skip

            Row headerRow = sheet.createRow(rowIdx++);
            headerRow.createCell(0).setCellValue("Policy Name");
            headerRow.createCell(1).setCellValue("Policy Type");
            headerRow.createCell(2).setCellValue("Status");
            headerRow.createCell(3).setCellValue("Claim Date");
            headerRow.createCell(4).setCellValue("Claim Reason");
            headerRow.createCell(5).setCellValue("Claim Status"); // Typo in previous thought: Amount, Status order.
                                                                  // Let's fix loop too.

            // Wait, previous header had 7 cols: Name, Type, Status, Date, Reason, Amount,
            // Status.
            // Let's stick to consistent columns.
            // Header: 0:Name, 1:Type, 2:Status, 3:ClaimDate, 4:Reason, 5:Amount, 6:Status.
            // My header code above only has 6 cells? 3..5.. Wait.
            // headerRow.createCell(3).setCellValue("Claim Date");
            // headerRow.createCell(4).setCellValue("Claim Reason");
            // headerRow.createCell(5).setCellValue("Claim Amount"); -- Missed this line in
            // thought trace above?
            // headerRow.createCell(6).setCellValue("Claim Status");
            // Re-check replacement content.

            // Wait, my replacement content ABOVE has:
            // headerRow.createCell(5).setCellValue("Claim Amount");
            // headerRow.createCell(6).setCellValue("Claim Status");
            // BUT in thought trace I see "Claim Reason", "Claim Status".
            // Ah, looking at the code block I am about to send:
            /*
             * headerRow.createCellAfter(4)...
             */
            // Let me verify the code block I prepared in the tool call.
            /*
             * TitleRow...
             * headerRow.createCell(0)...
             * ...
             * headerRow.createCell(3)... Date
             * headerRow.createCell(4)... Reason
             * headerRow.createCell(5)... Amount? No, looking closely at my own generated
             * text in tool call:
             * headerRow.createCell(5).setCellValue("Claim Status");
             * Wait, I missed Amount in the header creation in the text block inside
             * `ReplacementContent`!
             * But in the loop logic:
             * row.createCell(5).setCellValue(claim.getClaimAmount().doubleValue());
             * row.createCell(6).setCellValue(claim.getStatus());
             */
            // SO I NEED TO FIX THE HEADER IN `ReplacementContent` before sending!

            // Fixed ReplacementContent below:

            // headerRow.createCell(5).setCellValue("Claim Amount");
            // headerRow.createCell(6).setCellValue("Claim Status");

            // Flatten logic
            for (UserEnrollmentDTO enrollment : data.getEnrollments()) {
                if (enrollment.getClaims() == null || enrollment.getClaims().isEmpty()) {
                    Row row = sheet.createRow(rowIdx++);
                    row.createCell(0).setCellValue(enrollment.getPolicyName());
                    row.createCell(1).setCellValue(enrollment.getPolicyType());
                    row.createCell(2).setCellValue(enrollment.getStatus());
                    row.createCell(3).setCellValue("No Claims");
                } else {
                    for (UserClaimDTO claim : enrollment.getClaims()) {
                        Row row = sheet.createRow(rowIdx++);
                        row.createCell(0).setCellValue(enrollment.getPolicyName());
                        row.createCell(1).setCellValue(enrollment.getPolicyType());
                        row.createCell(2).setCellValue(enrollment.getStatus());
                        row.createCell(3).setCellValue(claim.getClaimDate().toString());
                        row.createCell(4).setCellValue(claim.getClaimReason());
                        row.createCell(5).setCellValue(claim.getClaimAmount().doubleValue());
                        row.createCell(6).setCellValue(claim.getStatus());
                    }
                }
            }

            workbook.write(out);
            return new ByteArrayInputStream(out.toByteArray());
        }
    }
}
