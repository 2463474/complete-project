package com.example.ghim.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ClaimReportDTO {
    private Long claimId;
    private String employeeName;
    private String policyName;
    private BigDecimal claimAmount;
    private String claimStatus;
    private LocalDate claimDate;
}
