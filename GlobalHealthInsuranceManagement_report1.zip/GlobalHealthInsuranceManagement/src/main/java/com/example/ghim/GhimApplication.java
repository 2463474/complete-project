package com.example.ghim;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GhimApplication {

	public static void main(String[] args) {
		SpringApplication.run(GhimApplication.class, args);
	}

}
