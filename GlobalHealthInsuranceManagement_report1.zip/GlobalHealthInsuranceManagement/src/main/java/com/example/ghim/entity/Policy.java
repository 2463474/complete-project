package com.example.ghim.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import java.math.BigDecimal;

@Entity
@Data
@Table(name = "Policy")
public class Policy {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long policyId;

    @NotBlank(message = "Policy Name is required")
    private String policyName;

    @DecimalMin(value = "0.0", inclusive = false, message = "Coverage amount must be positive")
    private BigDecimal coverageAmount;

    @DecimalMin(value = "0.0", inclusive = false, message = "Premium amount must be positive")
    private BigDecimal premiumAmount;

    @Enumerated(EnumType.STRING)
    private PolicyType policyType;

    public enum PolicyType {
        INDIVIDUAL, FAMILY
    }
}
