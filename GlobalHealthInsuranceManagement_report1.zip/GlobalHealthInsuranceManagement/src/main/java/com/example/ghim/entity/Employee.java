package com.example.ghim.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Entity
@Data
@Table(name = "Employee")
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long employeeId;

    @NotBlank(message = "Name is required")
    private String name;

    @Email(message = "Invalid email format")
    @NotBlank(message = "Email is required")
    private String email;

    private String phone;
    private String address;
    private String designation;

    // Assuming Organization is another entity, but for simplicity we'll just store
    // ID or make a simple relation if needed.
    // The prompt says organizationId (FK).
    private Long organizationId;
}
