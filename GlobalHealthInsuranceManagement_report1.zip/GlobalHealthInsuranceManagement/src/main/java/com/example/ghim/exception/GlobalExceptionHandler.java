package com.example.ghim.exception;

import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public String handleException(Exception ex, Model model) {
        // Log the exception
        ex.printStackTrace();

        // Pass error info to error view (Thymeleaf)
        model.addAttribute("errorMessage", ex.getMessage());
        return "error"; // Logical view name for error page
    }

    // You can add more specific exception handlers here
    // e.g. @ExceptionHandler(ResourceNotFoundException.class)
}
