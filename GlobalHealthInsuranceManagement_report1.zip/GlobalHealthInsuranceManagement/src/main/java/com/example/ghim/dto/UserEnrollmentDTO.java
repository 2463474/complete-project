package com.example.ghim.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserEnrollmentDTO {
    private String policyName;
    private String policyType;
    private LocalDate enrollmentDate;
    private String status;
    private BigDecimal premiumAmount;
    private List<UserClaimDTO> claims;
}
